package org.example;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

import java.util.Set;
import java.util.concurrent.TimeUnit;

public class Main {
    public static <Iterator> void main(String[] args) throws InstantiationException, IllegalAccessException {

        // declaration and instantiation of objects/variables--------------------------------------
        System.setProperty("webdriver.chrome.driver", "c:\\Chromedriver\\chromedriver.exe");
        // System.setProperty("webdriver.firefox.driver", "c:\\Chromedriver\\geckodriver.exe");
        // System.setProperty("webdriver.edge.driver", "c:\\Chromedriver\\msedgedriver.exe");
        WebDriver driver = new ChromeDriver();
        // WebDriver driver = new FirefoxDriver();
        // WebDriver driver = new EdgeDriver();
        driver.manage().window().maximize();

        // Login-----------------------------------------------------------------------------------
        driver.get("https://www.saucedemo.com/");
        driver.findElement(By.id("user-name")).sendKeys("standard_user");
        driver.findElement(By.id("password")).sendKeys("secret_sauce");
        driver.findElement(By.id("login-button")).click();
        String loginSuccess = "Login Success :-)";
        System.out.println(loginSuccess);
        // Ordel 1.--------------------------------------------------------------------------------
        driver.findElement(By.id("add-to-cart-sauce-labs-backpack")).click();
        driver.findElement(By.id("add-to-cart-sauce-labs-bike-light")).click();
        driver.findElement(By.id("add-to-cart-sauce-labs-onesie")).click();
        driver.findElement(By.className("shopping_cart_badge")).click();
        driver.findElement(By.id("checkout")).click();
        // Order filling out-----------------------------------------------------------------------
        driver.findElement(By.id("first-name")).sendKeys("Jan");
        driver.findElement(By.id("last-name")).sendKeys("Novotny");
        driver.findElement(By.id("postal-code")).sendKeys("68355");
        driver.findElement(By.id("continue")).click();
        // Control of goods------------------------------------------------------------------------
        driver.findElement(By.linkText("Sauce Labs Onesie")).click();
        driver.navigate().back();
        // Sending order---------------------------------------------------------------------------
        driver.findElement(By.id("finish")).click();
        String thankYou = driver.findElement(By.className("complete-header")).getText();
        System.out.println(thankYou);
        driver.findElement(By.id("back-to-products")).click();
        // ----------------------------------------------------------------------------------------
        // -----------------------------------------------------------------------------------------
        // New order 2.-----------------------------------------------------------------------------
        driver.findElement(By.linkText("Sauce Labs Backpack")).click();
        driver.findElement(By.id("add-to-cart-sauce-labs-backpack")).click();
        driver.findElement(By.className("shopping_cart_badge")).click();
        driver.findElement(By.id("checkout")).click();
        // Error order------------------------------------------------------------------------------
        driver.findElement(By.id("first-name")).sendKeys("Peter");
        driver.findElement(By.id("last-name")).sendKeys("");
        driver.findElement(By.id("postal-code")).sendKeys("04011");
        driver.findElement(By.id("continue")).click();
        // Clear the text written in the textbox and write correct text-----------------------------
        driver.findElement(By.id("first-name")).clear();
        driver.findElement(By.id("first-name")).sendKeys("Peter");
        driver.findElement(By.id("last-name")).clear();
        driver.findElement(By.id("last-name")).sendKeys("Petrovič");
        driver.findElement(By.id("postal-code")).clear();
        driver.findElement(By.id("postal-code")).sendKeys("04231");
        driver.findElement(By.id("continue")).click();
        // Finish order------------------------------------------------------------------------------
        driver.findElement(By.id("finish")).click();
        String thankYou1 = driver.findElement(By.className("complete-header")).getText();
        System.out.println(thankYou1);
        driver.findElement(By.id("back-to-products")).click();
        // selectDropdown 1--------------------------------------------------------------------------
        Select rozbal1 = new Select(driver.findElement(By.className("product_sort_container")));
        rozbal1.selectByVisibleText("Price (high to low)");
        // selectDropdown 2--------------------------------------------------------------------------
        Select rozbal2 = new Select(driver.findElement(By.className("product_sort_container")));
        rozbal2.selectByVisibleText("Price (low to high)");
        // selectDropdown 3--------------------------------------------------------------------------
        Select rozbal3 = new Select(driver.findElement(By.className("product_sort_container")));
        rozbal3.selectByVisibleText("Name (Z to A)");
        // selectDropdown 4--------------------------------------------------------------------------
        Select rozbal4 = new Select(driver.findElement(By.className("product_sort_container")));
        rozbal4.selectByVisibleText("Name (A to Z)");
        // Closa-------------------------------------------------------------------------------------
        driver.close();

    }
}